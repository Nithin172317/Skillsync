import { PrismaClient } from "@prisma/client";
import bcrypt from "bcrypt";

const prisma = new PrismaClient();

async function main() {
  const email = "demo@skillsync.dev";
  const password = "demo1234";
  const passwordHash = await bcrypt.hash(password, 10);

  const user = await prisma.user.upsert({
    where: { email },
    update: {},
    create: {
      email,
      name: "Demo User",
      passwordHash,
      skills: {
        create: [
          { name: "TypeScript", level: 40, notes: "Learning generics, utility types." },
          { name: "React", level: 55, notes: "Hooks patterns, performance." },
          { name: "SQL", level: 30, notes: "Joins, indexing." }
        ]
      }
    }
  });

  console.log("Seeded demo user:", user.email);
}

main().finally(() => prisma.$disconnect());
