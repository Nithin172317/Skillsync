# SkillSync — AI-Powered Skill Tracker

A portfolio-ready Next.js app to track your learning progress and get resource suggestions.
Built with **Next.js 14**, **TypeScript**, **Tailwind CSS**, **Prisma (SQLite)**, and **NextAuth**.
AI suggestions can be enabled with an `OPENAI_API_KEY`.

## Features
- 🔐 Auth (NextAuth Credentials + Prisma Adapter) — includes demo seed user
- 📊 Skills dashboard with progress bars
- 🏅 Milestone badges at 25/50/75/100%
- 🤖 AI suggestion endpoint (uses OpenAI if configured, otherwise mock data)
- 🌓 Dark mode
- ✅ ESLint & Prettier
- ⚙️ GitHub Actions CI (install → lint → typecheck → build)
- 🚀 Vercel-ready

## Quickstart

```bash
# 1) Install deps
npm install

# 2) Configure environment
cp .env.example .env

# 3) Initialize DB
npm run db:push

# 4) Seed demo user (email: demo@skillsync.dev, password: demo1234)
npm run db:seed

# 5) Dev server
npm run dev
```

Login with **demo@skillsync.dev / demo1234**.

## Environment

Edit `.env` (values are examples):

```
DATABASE_URL="file:./dev.db"
NEXTAUTH_SECRET="dev-secret-change-me"
NEXTAUTH_URL="http://localhost:3000"
# Optional: Enable AI suggestions
OPENAI_API_KEY=""
```

## Deploy (Vercel)
1. Push to GitHub.
2. Import the repo in Vercel.
3. Set the Environment Variables above (at least `DATABASE_URL`, `NEXTAUTH_SECRET`, `NEXTAUTH_URL`).
4. Add a **Build Command**: `npm run build`
5. Add a **Install Command**: `npm install`
6. Run `prisma db push` in a Post-Deploy script or Vercel's migration step.

## GitHub Setup

```bash
git init
git add .
git commit -m "feat: initial SkillSync app"
git branch -M main
# Create a new empty repo on GitHub, then:
git remote add origin https://github.com/<YOUR-USER>/skillsync.git
git push -u origin main
```

## Notes
- AI suggestions route returns mock data if no `OPENAI_API_KEY` is set.
- Credentials provider is for demo usage; consider OAuth (GitHub/Google) for production.
