"use client";
import { useState } from "react";

export default function SignInPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="max-w-sm mx-auto space-y-4">
      <h1 className="text-2xl font-semibold">Sign in</h1>
      <form method="post" action="/api/auth/callback/credentials" className="space-y-3">
        <input type="email" name="email" value={email} onChange={e=>setEmail(e.target.value)}
          placeholder="Email" className="w-full border rounded p-2" required />
        <input type="password" name="password" value={password} onChange={e=>setPassword(e.target.value)}
          placeholder="Password" className="w-full border rounded p-2" required />
        <button className="w-full border rounded p-2" type="submit">Sign in</button>
      </form>
      <p className="text-sm opacity-80">Demo: demo@skillsync.dev / demo1234</p>
    </div>
  );
}
