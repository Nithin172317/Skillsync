import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const key = process.env.OPENAI_API_KEY;
  // If no key, return mock suggestions.
  if (!key) {
    return NextResponse.json({
      suggestions: [
        { title: "TypeScript Handbook: Generics", url: "https://www.typescriptlang.org/docs/handbook/2/generics.html" },
        { title: "React Beta Docs: Performance", url: "https://react.dev/learn/you-might-not-need-an-effect" },
        { title: "SQL Indexing Best Practices", url: "https://use-the-index-luke.com/" }
      ]
    });
  }

  // Minimal example w/o external call to avoid network during local run.
  // In production, call OpenAI API here using fetch and your prompt.
  return NextResponse.json({
    suggestions: [
      { title: "OpenAI-enabled: Personalised roadmap tip #1", url: "#" },
      { title: "OpenAI-enabled: Personalised roadmap tip #2", url: "#" }
    ]
  });
}
