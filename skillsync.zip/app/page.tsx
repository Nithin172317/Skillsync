import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import AddSkillForm from "@/components/AddSkillForm";
import SkillCard from "@/components/SkillCard";
import BadgeList from "@/components/BadgeList";

export default async function Page() {
  const session = await getServerSession(authOptions);

  if (!session?.user?.email) {
    return (
      <section className="max-w-2xl mx-auto text-center space-y-6">
        <h1 className="text-3xl font-bold">Track your learning journey</h1>
        <p className="opacity-80">
          Add skills, update your progress, and get suggestions on what to learn next.
        </p>
        <a href="/signin" className="inline-block px-4 py-2 border rounded">Get started</a>
      </section>
    );
  }

  const user = await prisma.user.findUnique({
    where: { email: session.user.email },
    include: { skills: { orderBy: { updatedAt: "desc" } } }
  });

  return (
    <section className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-2xl font-semibold">Welcome back{user?.name ? `, ${user.name}` : ""}!</h1>
      <AddSkillForm />
      <div className="grid gap-4 sm:grid-cols-2">
        {user?.skills?.map((s) => <SkillCard key={s.id} skill={s} />)}
      </div>
      <BadgeList />
    </section>
  );
}
