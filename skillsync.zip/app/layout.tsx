import "./globals.css";
import { ReactNode } from "react";
import Link from "next/link";
import { ThemeToggle } from "@/components/ThemeToggle";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export const metadata = {
  title: "SkillSync",
  description: "Track your skills and get AI-powered suggestions."
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const session = await getServerSession(authOptions);
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-screen">
        <nav className="border-b">
          <div className="container flex items-center justify-between py-4">
            <Link href="/" className="font-semibold">SkillSync</Link>
            <div className="flex items-center gap-4">
              {session ? (
                <form action="/api/auth/signout" method="post">
                  <button className="px-3 py-1 border rounded">Sign out</button>
                </form>
              ) : (
                <Link href="/signin" className="px-3 py-1 border rounded">Sign in</Link>
              )}
              <ThemeToggle />
            </div>
          </div>
        </nav>
        <main className="container py-8">{children}</main>
        <footer className="border-t">
          <div className="container py-6 text-sm opacity-80">
            © {new Date().getFullYear()} SkillSync
          </div>
        </footer>
      </body>
    </html>
  );
}
