import type { Config } from "tailwindcss"

export default {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}"
  ],
  theme: {
    container: { center: true, padding: "1rem" },
    extend: {}
  },
  plugins: []
} satisfies Config
