"use client";
import { useState } from "react";

type Skill = {
  id: string;
  name: string;
  level: number;
  notes?: string | null;
};

export default function SkillCard({ skill }: { skill: Skill }) {
  const [level, setLevel] = useState(skill.level);
  const [notes, setNotes] = useState(skill.notes ?? "");
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    const res = await fetch("/api/skills", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: skill.id, name: skill.name, level, notes })
    });
    setSaving(false);
    if (!res.ok) alert("Failed to save");
  };

  const del = async () => {
    if (!confirm("Delete this skill?")) return;
    const res = await fetch(`/api/skills?id=${skill.id}`, { method: "DELETE" });
    if (res.ok) location.reload();
  };

  const badge =
    level >= 100 ? "Master" :
    level >= 75 ? "Expert" :
    level >= 50 ? "Intermediate" :
    level >= 25 ? "Novice" : "Starter";

  return (
    <div className="border rounded p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">{skill.name}</h3>
        <span className="text-sm opacity-80">{badge}</span>
      </div>
      <div>
        <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded">
          <div className="h-2 rounded bg-gray-500" style={{ width: `${level}%` }} />
        </div>
        <input
          type="range"
          min={0}
          max={100}
          value={level}
          onChange={(e) => setLevel(Number(e.target.value))}
          className="w-full"
        />
      </div>
      <textarea
        value={notes}
        onChange={(e) => setNotes(e.target.value)}
        placeholder="Notes..."
        className="w-full border rounded p-2"
      />
      <div className="flex gap-2">
        <button className="px-3 py-1 border rounded" onClick={save} disabled={saving}>
          {saving ? "Saving..." : "Save"}
        </button>
        <button className="px-3 py-1 border rounded" onClick={del}>
          Delete
        </button>
      </div>
    </div>
  );
}
