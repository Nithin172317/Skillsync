"use client";
import { useEffect, useState } from "react";

export default function BadgeList() {
  const [items, setItems] = useState<{ title: string; url: string }[]>([]);

  useEffect(() => {
    (async () => {
      const res = await fetch("/api/suggest");
      if (res.ok) {
        const data = await res.json();
        setItems(data.suggestions || []);
      }
    })();
  }, []);

  return (
    <div className="border rounded p-4 space-y-3">
      <h2 className="font-semibold">Suggested resources</h2>
      <ul className="list-disc pl-5 space-y-1">
        {items.map((it, idx) => (
          <li key={idx}>
            <a className="underline" href={it.url} target="_blank">{it.title}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}
