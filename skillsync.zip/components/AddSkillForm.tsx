"use client";
import { useState } from "react";

export default function AddSkillForm() {
  const [name, setName] = useState("");
  const [level, setLevel] = useState(0);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch("/api/skills", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, level })
    });
    setLoading(false);
    if (res.ok) {
      setName("");
      setLevel(0);
      location.reload();
    } else {
      alert("Failed to add skill");
    }
  };

  return (
    <form onSubmit={submit} className="border rounded p-4 space-y-3">
      <h2 className="font-semibold">Add a skill</h2>
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="e.g., TypeScript"
        className="w-full border rounded p-2"
        required
      />
      <input
        type="number"
        value={level}
        onChange={(e) => setLevel(Number(e.target.value))}
        min={0}
        max={100}
        className="w-full border rounded p-2"
      />
      <button className="px-3 py-1 border rounded" disabled={loading}>
        {loading ? "Adding..." : "Add"}
      </button>
    </form>
  );
}
